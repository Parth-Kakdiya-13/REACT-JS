import React from 'react';
import './backDrop.module.css';

export const BackDrop = () => {
    return (
        <div>

        </div>
    )
}
