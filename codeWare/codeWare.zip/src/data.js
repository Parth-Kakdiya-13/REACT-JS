const items = [
    {
        id: 'p1',
        heading: "TSHIRT",
        line: "The Boy Tshirt",
        price: "$" + 299,
        image: '/images/image01.webp',
        size: 'S'
    },
    {
        id: 'p2',
        heading: "TSHIRT",
        line: "The Boy Tshirt",
        price: "$" + 399,
        image: '/images/image02.webp',
        size: 'M'
    },
    {
        id: 'p3',
        heading: "TSHIRT",
        line: "The Boy Tshirt",
        price: "$" + 499,
        image: '/images/image03.webp',
        size: 'LG'
    },
    {
        id: 'p4',
        heading: "TSHIRT",
        line: "The Boy Tshirt",
        price: "$" + 199,
        image: '/images/image04.webp',
        size: 'S'
    },
    {
        id: 'p5',
        heading: "TSHIRT",
        line: "The Boy Tshirt",
        price: "$" + 599,
        image: '/images/image05.webp',
        size: 'XL'
    },
    {
        id: 'p6',
        heading: "TSHIRT",
        line: "The Boy Tshirt",
        price: "$" + 799,
        image: '/images/image06.webp',
        size: 'XXL'
    },

];

export default items;